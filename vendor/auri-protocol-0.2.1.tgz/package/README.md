# `@auri/protocol`

Contrato de comunicação compartilhado entre Auri Extension, Auri Desktop e o futuro bridge/native host. O pacote recebe dados JSON, valida a fronteira em runtime com Zod e oferece tipos TypeScript inferidos por método.

Ele **não** implementa transporte, Electron, APIs de extensão, banco, servidor, WebSocket, UI nem regras internas de domínio. O transporte inicialmente planejado é:

```text
Browser Extension → Native Messaging → Auri bridge/Desktop
```

O framing do Native Messaging e todos os demais detalhes de I/O pertencem aos projetos consumidores. O contrato continua válido caso o transporte mude.

## Versões

- Package version: `0.2.1`, usada para releases e evolução da biblioteca.
- Protocol version: `1`, presente no wire como `protocolVersion`.

A package version pode mudar sem alterar o protocolo. `protocolVersion` só aumenta quando houver uma mudança incompatível no formato wire. O pacote permanece `private: true` para impedir publicação acidental; isso não impede consumo local, por Git ou workspace. A publicação poderá ser habilitada depois que a distribuição do scope `@auri` for decidida.

## Envelope

Requests e responses usam `id` para correlação. Responses também carregam `method`, permitindo validar o `result` correto sem estado externo.

```json
{
  "kind": "request",
  "protocolVersion": 1,
  "id": "request-id",
  "method": "work.open",
  "params": { "workId": "work-1" }
}
```

```json
{
  "kind": "response",
  "protocolVersion": 1,
  "id": "request-id",
  "method": "work.open",
  "ok": true,
  "result": { "opened": true }
}
```

```json
{
  "kind": "response",
  "protocolVersion": 1,
  "id": "request-id",
  "method": "work.open",
  "ok": false,
  "error": {
    "code": "WORK_NOT_FOUND",
    "message": "Obra não encontrada"
  }
}
```

Todos os objetos continuam estritos: campos desconhecidos, método, versão, params ou result inválidos são rejeitados. A única abertura intencional é o nome de cada capability anunciada no `system.hello`, que aceita nomes futuros com formato e tamanho limitados.

## Handshake e compatibilidade

`system.hello` é o handshake básico, não uma capability opcional. O cliente informa sua identidade e `supportedProtocolVersions`; o servidor devolve a versão selecionada, sua identidade e as capabilities suportadas. As versões dos aplicativos são fornecidas pelos consumidores e não são fixadas pelo pacote.

- `protocolVersion` resolve diferenças incompatíveis de **wire format**. Peers incompatíveis não devem continuar a operação normal.
- `capabilities` resolvem diferenças de **feature**. O cliente deve ocultar ou desabilitar ações ausentes.
- `capabilitySchema` valida nomes recebidos no wire sem exigir que esta versão já os conheça.
- `KnownCapability`, `knownCapabilitySchema` e `isKnownCapability` preservam autocomplete, validação e narrowing para o catálogo conhecido.

Capabilities conhecidas: `work.resolve`, `work.context`, `work.open`, `source.add`, `progress.update`, `desktop.openAddWork` e `desktop.openAddWork.coverUrl`.

Consumers devem ignorar capabilities desconhecidas. O array aceita no máximo 64 nomes únicos; cada nome tem até 128 caracteres e usa segmentos separados por ponto.

> Migração: versões até `0.1.2` usavam um enum fechado e rejeitavam capabilities desconhecidas. Um consumer já instalado com essa versão não pode ser corrigido retroativamente. Atualize Desktop e Extension para `0.1.3` antes de anunciar capabilities posteriores, ou faça o Desktop omitir novas capabilities para peers que ainda usam o contrato antigo.

## Métodos v1

- `system.hello`: negocia protocolo, identidade e funcionalidades.
- `work.resolve`: recebe `PageContext` e retorna `matched`, `not_found` ou `ambiguous`.
- `work.context`: consulta o contexto de leitura de uma obra já resolvida. Retorna status, progresso, relação da página, estado da fonte e um destino explícito para continuar.
- `work.open`: solicita que o Desktop mostre uma obra.
- `desktop.openAddWork`: solicita a abertura do formulário real com um draft limitado. `coverUrl` é metadata HTTP(S) opcional e só deve ser enviada quando `desktop.openAddWork.coverUrl` for anunciada.
- `source.add`: transporta a intenção de adicionar uma fonte sem definir preferência ou invariantes internas.
- `progress.update`: transporta capítulo textual e contexto opcional; regressão, histórico e Undo continuam no Desktop.

O fluxo de integração 2.0 é `system.hello → work.resolve → work.context`. O novo método é aditivo: a Extension deve chamá-lo somente quando o Desktop anunciar a capability `work.context`; caso contrário, usa o fluxo anterior.

`work.context` recebe `workId` e um recorte estrito de `PageContext` com URL, URL canônica e capítulo detectado. O resultado usa o `UserStatus` real do domínio Auri, reutiliza `ChapterValue` para progresso e destino, e representa:

- relação da página: `series_page`, `same`, `ahead`, `behind` ou `unknown`;
- estado da fonte: `linked`, `unlinked` ou `ambiguous`;
- `continueTarget` como URL HTTP(S) real devolvida pelo Desktop ou `null`.

O protocolo não compara capítulos, resolve fontes nem constrói o destino de continuação. Essas decisões pertencem ao Desktop.

## Uso

```ts
import {
  createRequest,
  isKnownCapability,
  parseProtocolMessage,
  safeParseProtocolMessage,
} from "@auri/protocol";

const outgoing = createRequest("ext-42", "work.resolve", {
  url: "https://reader.example/work/chapter-327.5",
  title: "Example Work — Chapter 327.5",
  detectedChapter: {
    value: "327.5",
    numericValue: 327.5,
    confidence: "high",
    source: "page-title",
  },
});

// No lado Desktop, depois que o transporte entregar o JSON:
const parsed = safeParseProtocolMessage(outgoing);
if (!parsed.success) {
  // Converter a falha para um ProtocolError adequado na fronteira.
}

const trustedMessage = parseProtocolMessage(outgoing);

// Capabilities futuras não invalidam o hello; filtre as que este consumer conhece.
const knownCapabilities = ["work.resolve", "library.sync"].filter(
  isKnownCapability,
);
```

Também são exportados `parseRequest`, `parseResponse`, suas variantes `safeParse*`, schemas reutilizáveis e helpers `createSuccessResponse`/`createErrorResponse`.

O mapa `protocolMethodSchemas` é a fonte de verdade para params e result. Assim, `ProtocolRequest<'progress.update'>` infere os params corretos e `ProtocolResult<'work.resolve'>` infere a união discriminada do resultado.

A versão `0.2.0` continua usando `PROTOCOL_VERSION = 1`: o envelope e os métodos anteriores não mudaram; `work.context` e sua capability são extensões opcionais do wire v1.

A versão `0.2.1` usa Zod 4.6.6 e mantém esses contratos. Os arrays têm limites aplicados antes da validação de itens. Os detalhes de erro também têm a quantidade de chaves limitada antes da validação dos valores.

## Erros

Os códigos públicos são: `INVALID_MESSAGE`, `UNSUPPORTED_PROTOCOL_VERSION`, `METHOD_NOT_SUPPORTED`, `INVALID_PARAMS`, `UNAUTHORIZED_CLIENT`, `AURI_NOT_READY`, `WORK_NOT_FOUND`, `SOURCE_NOT_FOUND`, `AMBIGUOUS_MATCH`, `CONFLICT`, `VALIDATION_ERROR`, `OPERATION_CANCELLED` e `INTERNAL_ERROR`.

`ProtocolError.details`, quando usado, aceita no máximo 16 pares rasos com valores `string`, `number`, `boolean` ou `null`. Nunca envie stack traces, erros brutos, dados de banco ou informação sensível.

## Segurança

Schemas aplicam limites a IDs, títulos, capítulos, nomes, URLs, erros e candidatos. URLs, incluindo `coverUrl`, aceitam apenas HTTP(S); `data:`, `blob:` e `file:` são rejeitados. O campo opcional `domain` é somente metadata: o Desktop deve derivar e validar o hostname real de `url` para decisões sensíveis. Aceitar `coverUrl` no protocolo não substitui as proteções do Desktop para download de conteúdo remoto.

`MAX_PROTOCOL_MESSAGE_BYTES` recomenda o limite conservador de 256 KiB para JSON serializado. O pacote não implementa medição, serialização ou framing. O wire aceita somente estruturas JSON-safe; não use `Date`, `Map`, `Set`, `BigInt`, `Buffer`, `Error` ou instâncias de classes.

## Desenvolvimento

```sh
npm install
npm test
npm run typecheck
npm run build
```

O build gera ESM, CommonJS, declarations e sourcemaps em `dist/`. Consumidores devem importar apenas de `@auri/protocol`, nunca de caminhos internos.

## Adicionando um método

1. Crie schemas estritos de `params` e `result` em `src/methods.ts`.
2. Registre-os em `protocolMethodSchemas` e em `PROTOCOL_METHODS`.
3. Inclua os envelopes do método em `src/message.ts`.
4. Adicione uma `KnownCapability` somente se a feature for opcional e negociável; nomes wire desconhecidos já são tolerados.
5. Cubra request, response, rejeições e inferência no teste.
6. Aumente `protocolVersion` apenas se o wire mudar de forma incompatível.
