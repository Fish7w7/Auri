import { z } from "zod";

import {
  PROTOCOL_LIMITS,
  PROTOCOL_METHOD,
  PROTOCOL_VERSION,
} from "./constants.js";
import {
  capabilitySchema,
  chapterValueSchema,
  coverUrlSchema,
  detectedChapterSchema,
  domainSchema,
  entityIdSchema,
  httpUrlSchema,
  nameSchema,
  pageContextSchema,
  pageRelationSchema,
  peerInfoSchema,
  sourceLinkStateSchema,
  sourceSummarySchema,
  titleSchema,
  userStatusSchema,
  workSummarySchema,
} from "./schemas.js";

const matchInfoSchema = z
  .object({
    matchedBy: z.enum(["source_url", "source_domain", "title", "alias"]),
    confidence: z.enum(["exact", "high", "possible"]),
  })
  .strict();

const matchCandidateSchema = z
  .object({
    work: workSummarySchema,
    source: sourceSummarySchema.optional(),
    match: matchInfoSchema,
  })
  .strict();

export const systemHelloParamsSchema = z
  .object({
    client: peerInfoSchema,
    supportedProtocolVersions: z
      .array(z.number().positive().refine(Number.isInteger, "Must be an integer"))
      .min(1)
      .max(PROTOCOL_LIMITS.supportedProtocolVersions)
      .refine((versions) => new Set(versions).size === versions.length, {
        message: "Protocol versions must be unique",
      }),
  })
  .strict();

export const systemHelloResultSchema = z
  .object({
    protocolVersion: z.literal(PROTOCOL_VERSION),
    server: peerInfoSchema,
    capabilities: z
      .array(capabilitySchema)
      .max(PROTOCOL_LIMITS.capabilities)
      .refine((items) => new Set(items).size === items.length, {
        message: "Capabilities must be unique",
      }),
  })
  .strict();

export const workResolveParamsSchema = pageContextSchema;
export const workResolveResultSchema = z.discriminatedUnion("status", [
  z.object({ status: z.literal("not_found") }).strict(),
  z
    .object({
      status: z.literal("matched"),
      work: workSummarySchema,
      source: sourceSummarySchema.optional(),
      match: matchInfoSchema,
    })
    .strict(),
  z
    .object({
      status: z.literal("ambiguous"),
      candidates: z
        .array(matchCandidateSchema)
        .min(2)
        .max(PROTOCOL_LIMITS.candidates),
    })
    .strict(),
]);

export const workContextPageParamsSchema = pageContextSchema
  .pick({
    url: true,
    canonicalUrl: true,
    detectedChapter: true,
  })
  .extend({
    detectedChapter: detectedChapterSchema.nullable().optional(),
  })
  .strict();

export const workContextParamsSchema = z
  .object({
    workId: entityIdSchema,
    page: workContextPageParamsSchema,
  })
  .strict();

export const workContextWorkSchema = z
  .object({
    id: entityIdSchema,
    title: titleSchema,
    userStatus: userStatusSchema,
    progress: chapterValueSchema.nullable(),
  })
  .strict();

export const workContextPageResultSchema = z
  .object({
    detectedChapter: detectedChapterSchema.nullable(),
    relation: pageRelationSchema,
  })
  .strict();

export const workContextSourceSchema = z
  .object({
    state: sourceLinkStateSchema,
    matchedSourceId: entityIdSchema.optional(),
    name: nameSchema.optional(),
    domain: domainSchema.optional(),
    seriesUrl: httpUrlSchema.optional(),
    lastReadUrl: httpUrlSchema.optional(),
  })
  .strict();

export const continueTargetSchema = z
  .object({
    url: httpUrlSchema,
    chapter: chapterValueSchema.optional(),
  })
  .strict();

export const workContextResultSchema = z
  .object({
    work: workContextWorkSchema,
    page: workContextPageResultSchema,
    source: workContextSourceSchema,
    continueTarget: continueTargetSchema.nullable(),
  })
  .strict();

export const workOpenParamsSchema = z.object({ workId: entityIdSchema }).strict();
export const workOpenResultSchema = z.object({ opened: z.literal(true) }).strict();

export const desktopOpenAddWorkParamsSchema = z
  .object({
    title: titleSchema.optional(),
    pageUrl: httpUrlSchema,
    canonicalUrl: httpUrlSchema.optional(),
    detectedChapter: detectedChapterSchema.optional(),
    sourceName: nameSchema.optional(),
    coverUrl: coverUrlSchema.optional(),
  })
  .strict();
export const desktopOpenAddWorkResultSchema = z
  .object({ opened: z.literal(true) })
  .strict();

export const sourceAddParamsSchema = z
  .object({
    workId: entityIdSchema,
    url: httpUrlSchema,
    name: nameSchema.optional(),
    language: z
      .string()
      .min(2)
      .max(35)
      .regex(/^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/u)
      .optional(),
  })
  .strict();
export const sourceAddResultSchema = z.object({ source: sourceSummarySchema }).strict();

export const progressUpdateParamsSchema = z
  .object({
    workId: entityIdSchema,
    chapter: chapterValueSchema,
    sourceId: entityIdSchema.optional(),
    pageUrl: httpUrlSchema.optional(),
  })
  .strict();
export const progressUpdateResultSchema = z
  .object({ updated: z.literal(true) })
  .strict();

/** Fonte única de verdade para params e result de cada método. */
export const protocolMethodSchemas = {
  [PROTOCOL_METHOD.systemHello]: {
    params: systemHelloParamsSchema,
    result: systemHelloResultSchema,
  },
  [PROTOCOL_METHOD.workResolve]: {
    params: workResolveParamsSchema,
    result: workResolveResultSchema,
  },
  [PROTOCOL_METHOD.workContext]: {
    params: workContextParamsSchema,
    result: workContextResultSchema,
  },
  [PROTOCOL_METHOD.workOpen]: {
    params: workOpenParamsSchema,
    result: workOpenResultSchema,
  },
  [PROTOCOL_METHOD.desktopOpenAddWork]: {
    params: desktopOpenAddWorkParamsSchema,
    result: desktopOpenAddWorkResultSchema,
  },
  [PROTOCOL_METHOD.sourceAdd]: {
    params: sourceAddParamsSchema,
    result: sourceAddResultSchema,
  },
  [PROTOCOL_METHOD.progressUpdate]: {
    params: progressUpdateParamsSchema,
    result: progressUpdateResultSchema,
  },
} as const;

type MethodSchemas = typeof protocolMethodSchemas;

export type ProtocolMethodMap = {
  [Method in keyof MethodSchemas]: {
    params: z.infer<MethodSchemas[Method]["params"]>;
    result: z.infer<MethodSchemas[Method]["result"]>;
  };
};

export type ProtocolParams<Method extends keyof ProtocolMethodMap> =
  ProtocolMethodMap[Method]["params"];

export type ProtocolResult<Method extends keyof ProtocolMethodMap> =
  ProtocolMethodMap[Method]["result"];

export type SystemHelloParams = ProtocolParams<"system.hello">;
export type SystemHelloResult = ProtocolResult<"system.hello">;
export type WorkResolveParams = ProtocolParams<"work.resolve">;
export type WorkResolveResult = ProtocolResult<"work.resolve">;
export type WorkContextParams = ProtocolParams<"work.context">;
export type WorkContextResult = ProtocolResult<"work.context">;
export type WorkContextPageParams = z.infer<typeof workContextPageParamsSchema>;
export type WorkContextWork = z.infer<typeof workContextWorkSchema>;
export type WorkContextPageResult = z.infer<typeof workContextPageResultSchema>;
export type WorkContextSource = z.infer<typeof workContextSourceSchema>;
export type ContinueTarget = z.infer<typeof continueTargetSchema>;
export type WorkOpenParams = ProtocolParams<"work.open">;
export type WorkOpenResult = ProtocolResult<"work.open">;
export type DesktopOpenAddWorkParams = ProtocolParams<"desktop.openAddWork">;
export type DesktopOpenAddWorkResult = ProtocolResult<"desktop.openAddWork">;
export type SourceAddParams = ProtocolParams<"source.add">;
export type SourceAddResult = ProtocolResult<"source.add">;
export type ProgressUpdateParams = ProtocolParams<"progress.update">;
export type ProgressUpdateResult = ProtocolResult<"progress.update">;
