import { z } from "zod";

import {
  PROTOCOL_METHOD,
  PROTOCOL_VERSION,
  type ProtocolMethod,
} from "./constants.js";
import {
  protocolMethodSchemas,
  type ProtocolParams,
  type ProtocolResult,
} from "./methods.js";
import { protocolErrorSchema, requestIdSchema, type ProtocolError } from "./schemas.js";

const requestEnvelope = <Method extends ProtocolMethod, Schema extends z.ZodTypeAny>(
  method: Method,
  params: Schema,
) =>
  z
    .object({
      kind: z.literal("request"),
      protocolVersion: z.literal(PROTOCOL_VERSION),
      id: requestIdSchema,
      method: z.literal(method),
      params,
    })
    .strict();

const successEnvelope = <Method extends ProtocolMethod, Schema extends z.ZodTypeAny>(
  method: Method,
  result: Schema,
) =>
  z
    .object({
      kind: z.literal("response"),
      protocolVersion: z.literal(PROTOCOL_VERSION),
      id: requestIdSchema,
      method: z.literal(method),
      ok: z.literal(true),
      result,
    })
    .strict();

const errorEnvelope = <Method extends ProtocolMethod>(method: Method) =>
  z
    .object({
      kind: z.literal("response"),
      protocolVersion: z.literal(PROTOCOL_VERSION),
      id: requestIdSchema,
      method: z.literal(method),
      ok: z.literal(false),
      error: protocolErrorSchema,
    })
    .strict();

const methodEntries = [
  PROTOCOL_METHOD.systemHello,
  PROTOCOL_METHOD.workResolve,
  PROTOCOL_METHOD.workContext,
  PROTOCOL_METHOD.workOpen,
  PROTOCOL_METHOD.desktopOpenAddWork,
  PROTOCOL_METHOD.sourceAdd,
  PROTOCOL_METHOD.progressUpdate,
] as const;

export const protocolRequestSchema = z.discriminatedUnion("method", [
  requestEnvelope(
    PROTOCOL_METHOD.systemHello,
    protocolMethodSchemas[PROTOCOL_METHOD.systemHello].params,
  ),
  requestEnvelope(
    PROTOCOL_METHOD.workResolve,
    protocolMethodSchemas[PROTOCOL_METHOD.workResolve].params,
  ),
  requestEnvelope(
    PROTOCOL_METHOD.workContext,
    protocolMethodSchemas[PROTOCOL_METHOD.workContext].params,
  ),
  requestEnvelope(
    PROTOCOL_METHOD.workOpen,
    protocolMethodSchemas[PROTOCOL_METHOD.workOpen].params,
  ),
  requestEnvelope(
    PROTOCOL_METHOD.desktopOpenAddWork,
    protocolMethodSchemas[PROTOCOL_METHOD.desktopOpenAddWork].params,
  ),
  requestEnvelope(
    PROTOCOL_METHOD.sourceAdd,
    protocolMethodSchemas[PROTOCOL_METHOD.sourceAdd].params,
  ),
  requestEnvelope(
    PROTOCOL_METHOD.progressUpdate,
    protocolMethodSchemas[PROTOCOL_METHOD.progressUpdate].params,
  ),
]);

export const protocolSuccessResponseSchema = z.discriminatedUnion("method", [
  successEnvelope(
    PROTOCOL_METHOD.systemHello,
    protocolMethodSchemas[PROTOCOL_METHOD.systemHello].result,
  ),
  successEnvelope(
    PROTOCOL_METHOD.workResolve,
    protocolMethodSchemas[PROTOCOL_METHOD.workResolve].result,
  ),
  successEnvelope(
    PROTOCOL_METHOD.workContext,
    protocolMethodSchemas[PROTOCOL_METHOD.workContext].result,
  ),
  successEnvelope(
    PROTOCOL_METHOD.workOpen,
    protocolMethodSchemas[PROTOCOL_METHOD.workOpen].result,
  ),
  successEnvelope(
    PROTOCOL_METHOD.desktopOpenAddWork,
    protocolMethodSchemas[PROTOCOL_METHOD.desktopOpenAddWork].result,
  ),
  successEnvelope(
    PROTOCOL_METHOD.sourceAdd,
    protocolMethodSchemas[PROTOCOL_METHOD.sourceAdd].result,
  ),
  successEnvelope(
    PROTOCOL_METHOD.progressUpdate,
    protocolMethodSchemas[PROTOCOL_METHOD.progressUpdate].result,
  ),
]);

export const protocolErrorResponseSchema = z.discriminatedUnion("method", [
  errorEnvelope(methodEntries[0]),
  errorEnvelope(methodEntries[1]),
  errorEnvelope(methodEntries[2]),
  errorEnvelope(methodEntries[3]),
  errorEnvelope(methodEntries[4]),
  errorEnvelope(methodEntries[5]),
  errorEnvelope(methodEntries[6]),
]);

export const protocolResponseSchema = z.union([
  protocolSuccessResponseSchema,
  protocolErrorResponseSchema,
]);

export const protocolMessageSchema = z.union([
  protocolRequestSchema,
  protocolResponseSchema,
]);

export type ProtocolRequest<Method extends ProtocolMethod = ProtocolMethod> =
  Method extends ProtocolMethod
    ? {
        kind: "request";
        protocolVersion: typeof PROTOCOL_VERSION;
        id: string;
        method: Method;
        params: ProtocolParams<Method>;
      }
    : never;

export type ProtocolSuccessResponse<
  Method extends ProtocolMethod = ProtocolMethod,
> = Method extends ProtocolMethod
  ? {
      kind: "response";
      protocolVersion: typeof PROTOCOL_VERSION;
      id: string;
      method: Method;
      ok: true;
      result: ProtocolResult<Method>;
    }
  : never;

export type ProtocolErrorResponse<
  Method extends ProtocolMethod = ProtocolMethod,
> = Method extends ProtocolMethod
  ? {
      kind: "response";
      protocolVersion: typeof PROTOCOL_VERSION;
      id: string;
      method: Method;
      ok: false;
      error: ProtocolError;
    }
  : never;

export type ProtocolResponse<Method extends ProtocolMethod = ProtocolMethod> =
  | ProtocolSuccessResponse<Method>
  | ProtocolErrorResponse<Method>;

export type ProtocolMessage = ProtocolRequest | ProtocolResponse;

export type WorkContextRequest = ProtocolRequest<"work.context">;
export type WorkContextResponse = ProtocolResponse<"work.context">;

export const parseRequest = (input: unknown): ProtocolRequest =>
  protocolRequestSchema.parse(input);

export const safeParseRequest = (
  input: unknown,
): z.ZodSafeParseResult<ProtocolRequest> => protocolRequestSchema.safeParse(input);

export const parseResponse = (input: unknown): ProtocolResponse =>
  protocolResponseSchema.parse(input);

export const safeParseResponse = (
  input: unknown,
): z.ZodSafeParseResult<ProtocolResponse> =>
  protocolResponseSchema.safeParse(input);

export const parseProtocolMessage = (input: unknown): ProtocolMessage =>
  protocolMessageSchema.parse(input);

export const safeParseProtocolMessage = (
  input: unknown,
): z.ZodSafeParseResult<ProtocolMessage> =>
  protocolMessageSchema.safeParse(input);

export const createRequest = <Method extends ProtocolMethod>(
  id: string,
  method: Method,
  params: ProtocolParams<Method>,
): ProtocolRequest<Method> =>
  parseRequest({
    kind: "request",
    protocolVersion: PROTOCOL_VERSION,
    id,
    method,
    params,
  }) as ProtocolRequest<Method>;

export const createSuccessResponse = <Method extends ProtocolMethod>(
  id: string,
  method: Method,
  result: ProtocolResult<Method>,
): ProtocolSuccessResponse<Method> =>
  parseResponse({
    kind: "response",
    protocolVersion: PROTOCOL_VERSION,
    id,
    method,
    ok: true,
    result,
  }) as ProtocolSuccessResponse<Method>;

export const createErrorResponse = <Method extends ProtocolMethod>(
  id: string,
  method: Method,
  error: ProtocolError,
): ProtocolErrorResponse<Method> =>
  parseResponse({
    kind: "response",
    protocolVersion: PROTOCOL_VERSION,
    id,
    method,
    ok: false,
    error,
  }) as ProtocolErrorResponse<Method>;
