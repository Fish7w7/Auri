import { z } from "zod";

import {
  KNOWN_CAPABILITIES,
  PAGE_RELATIONS,
  PEER_KINDS,
  PROTOCOL_ERROR_CODES,
  PROTOCOL_LIMITS,
  SOURCE_LINK_STATES,
  USER_STATUSES,
} from "./constants.js";

const boundedNonEmptyString = (maximum: number) =>
  z
    .string()
    .min(1)
    .max(maximum)
    .refine((value) => value.trim().length > 0, "Must not contain only whitespace");

export const requestIdSchema = boundedNonEmptyString(PROTOCOL_LIMITS.requestId);
export const entityIdSchema = boundedNonEmptyString(PROTOCOL_LIMITS.entityId);
export const titleSchema = boundedNonEmptyString(PROTOCOL_LIMITS.title);
export const nameSchema = boundedNonEmptyString(PROTOCOL_LIMITS.name);
export const chapterTextSchema = boundedNonEmptyString(PROTOCOL_LIMITS.chapter);

const createHttpUrlSchema = (maximum: number) =>
  z
    .string()
    .min(1)
    .max(maximum)
    .refine((value) => {
      try {
        const protocol = new URL(value).protocol;
        return protocol === "http:" || protocol === "https:";
      } catch {
        return false;
      }
    }, "Must be an HTTP(S) URL");

export const httpUrlSchema = createHttpUrlSchema(PROTOCOL_LIMITS.url);
export const coverUrlSchema = createHttpUrlSchema(PROTOCOL_LIMITS.coverUrl);

export const domainSchema = z
  .string()
  .min(1)
  .max(253)
  .refine(
    (value) =>
      value.trim() === value &&
      value.split(".").every(
        (label) =>
          label.length >= 1 &&
          label.length <= 63 &&
          /^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/u.test(label),
      ),
    { message: "Must be a hostname without scheme, path, or port" },
  );

/** Nome de capability recebido no wire, aberto para evolução futura. */
export const capabilitySchema = z
  .string()
  .min(1)
  .max(PROTOCOL_LIMITS.capability)
  .regex(/^[A-Za-z][A-Za-z0-9]*(?:\.[A-Za-z][A-Za-z0-9]*)+$/u);

/** Capabilities que esta versão do pacote conhece semanticamente. */
export const knownCapabilitySchema = z.enum(KNOWN_CAPABILITIES);

export type WireCapability = z.infer<typeof capabilitySchema>;

export const isKnownCapability = (
  capability: WireCapability,
): capability is z.infer<typeof knownCapabilitySchema> =>
  knownCapabilitySchema.safeParse(capability).success;

export const peerKindSchema = z.enum(PEER_KINDS);
export const protocolErrorCodeSchema = z.enum(PROTOCOL_ERROR_CODES);
export const userStatusSchema = z.enum(USER_STATUSES);
export const pageRelationSchema = z.enum(PAGE_RELATIONS);
export const sourceLinkStateSchema = z.enum(SOURCE_LINK_STATES);

export const chapterValueSchema = z
  .object({
    value: chapterTextSchema,
    numericValue: z.number().finite().optional(),
  })
  .strict();

export type ChapterValue = z.infer<typeof chapterValueSchema>;

export const detectedChapterSchema = chapterValueSchema
  .extend({
    confidence: z.enum(["high", "medium", "low"]),
    source: z.enum(["url", "page-title", "metadata", "manual"]),
  })
  .strict();

export type DetectedChapter = z.infer<typeof detectedChapterSchema>;

export const pageContextSchema = z
  .object({
    url: httpUrlSchema,
    canonicalUrl: httpUrlSchema.optional(),
    title: titleSchema.optional(),
    siteName: nameSchema.optional(),
    domain: domainSchema.optional(),
    detectedChapter: detectedChapterSchema.optional(),
  })
  .strict();

export type PageContext = z.infer<typeof pageContextSchema>;

export const peerInfoSchema = z
  .object({
    kind: peerKindSchema,
    name: nameSchema,
    version: z.string().min(1).max(64),
  })
  .strict();

export type PeerInfo = z.infer<typeof peerInfoSchema>;

export const workSummarySchema = z
  .object({
    id: entityIdSchema,
    title: titleSchema,
    currentChapter: chapterValueSchema.nullable().optional(),
    favorite: z.boolean().optional(),
  })
  .strict();

export type WorkSummary = z.infer<typeof workSummarySchema>;

export const sourceStatusSchema = z.enum(["active", "unavailable", "archived"]);
export type SourceStatus = z.infer<typeof sourceStatusSchema>;

export const sourceSummarySchema = z
  .object({
    id: entityIdSchema,
    name: nameSchema.optional(),
    domain: domainSchema,
    status: sourceStatusSchema,
    isPreferred: z.boolean(),
    lastReadUrl: httpUrlSchema.optional(),
  })
  .strict();

export type SourceSummary = z.infer<typeof sourceSummarySchema>;

const protocolErrorDetailValueSchema = z.union([
  z.string().max(PROTOCOL_LIMITS.errorDetailString),
  z.number().finite(),
  z.boolean(),
  z.null(),
]);

const protocolErrorDetailRecordSchema = z.record(
  z.string().min(1).max(PROTOCOL_LIMITS.errorDetailKey),
  protocolErrorDetailValueSchema,
);

export const protocolErrorDetailsSchema = z
  .custom<Record<string, z.input<typeof protocolErrorDetailValueSchema>>>((value) => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) return false;

    let keyCount = 0;
    for (const key in value) {
      if (key !== "__proto__" && ++keyCount > PROTOCOL_LIMITS.errorDetailKeys) return false;
    }

    // Zod 3 validated this key's value and dropped the key from the result.
    const descriptor = Object.getOwnPropertyDescriptor(value, "__proto__");
    return !descriptor?.enumerable || protocolErrorDetailValueSchema.safeParse(descriptor.value).success;
  }, `Must be a record with at most ${PROTOCOL_LIMITS.errorDetailKeys} keys`)
  .pipe(protocolErrorDetailRecordSchema);

export type ProtocolErrorDetails = z.infer<typeof protocolErrorDetailsSchema>;

export const protocolErrorSchema = z
  .object({
    code: protocolErrorCodeSchema,
    message: boundedNonEmptyString(PROTOCOL_LIMITS.errorMessage),
    details: protocolErrorDetailsSchema.optional(),
  })
  .strict();

export type ProtocolError = z.infer<typeof protocolErrorSchema>;
