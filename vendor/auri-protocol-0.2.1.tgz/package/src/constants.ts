export const PROTOCOL_VERSION = 1 as const;

/** Limite recomendado para a mensagem JSON já serializada. */
export const MAX_PROTOCOL_MESSAGE_BYTES = 256 * 1024;

export const PROTOCOL_METHOD = {
  systemHello: "system.hello",
  workResolve: "work.resolve",
  workContext: "work.context",
  workOpen: "work.open",
  desktopOpenAddWork: "desktop.openAddWork",
  sourceAdd: "source.add",
  progressUpdate: "progress.update",
} as const;

export const PROTOCOL_METHODS = Object.values(PROTOCOL_METHOD);

export type ProtocolMethod = (typeof PROTOCOL_METHODS)[number];

/** Funcionalidades conhecidas por esta versão do pacote. */
export const KNOWN_CAPABILITIES = [
  "work.resolve",
  "work.context",
  "work.open",
  "source.add",
  "progress.update",
  "desktop.openAddWork",
  "desktop.openAddWork.coverUrl",
] as const;

/** Alias mantido para compatibilidade com consumidores existentes. */
export const CAPABILITIES = KNOWN_CAPABILITIES;

export type KnownCapability = (typeof KNOWN_CAPABILITIES)[number];

/** @deprecated Prefira KnownCapability para capabilities conhecidas. */
export type Capability = KnownCapability;

export const USER_STATUSES = [
  "want_to_read",
  "reading",
  "paused",
  "waiting",
  "completed",
  "dropped",
] as const;

export type UserStatus = (typeof USER_STATUSES)[number];

export const PAGE_RELATIONS = [
  "series_page",
  "same",
  "ahead",
  "behind",
  "unknown",
] as const;

export type PageRelation = (typeof PAGE_RELATIONS)[number];

export const SOURCE_LINK_STATES = ["linked", "unlinked", "ambiguous"] as const;

export type SourceLinkState = (typeof SOURCE_LINK_STATES)[number];

export const PEER_KINDS = ["extension", "desktop", "native-host"] as const;
export type PeerKind = (typeof PEER_KINDS)[number];

export const PROTOCOL_ERROR_CODES = [
  "INVALID_MESSAGE",
  "UNSUPPORTED_PROTOCOL_VERSION",
  "METHOD_NOT_SUPPORTED",
  "INVALID_PARAMS",
  "UNAUTHORIZED_CLIENT",
  "AURI_NOT_READY",
  "WORK_NOT_FOUND",
  "SOURCE_NOT_FOUND",
  "AMBIGUOUS_MATCH",
  "CONFLICT",
  "VALIDATION_ERROR",
  "OPERATION_CANCELLED",
  "INTERNAL_ERROR",
] as const;

export type ProtocolErrorCode = (typeof PROTOCOL_ERROR_CODES)[number];

export const PROTOCOL_LIMITS = {
  requestId: 128,
  entityId: 128,
  name: 160,
  title: 512,
  chapter: 128,
  url: 8_192,
  coverUrl: 8_192,
  capability: 128,
  errorMessage: 1_024,
  errorDetailKeys: 16,
  errorDetailKey: 64,
  errorDetailString: 512,
  candidates: 20,
  capabilities: 64,
  supportedProtocolVersions: 16,
} as const;
